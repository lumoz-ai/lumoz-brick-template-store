import base64
from time import time

import cv2
import numpy
import requests
from bricksdk import get_brick
from bricksdk.brick_processors.generic_brick_processor import GenericBrickProcessor

from protos import image_detection_3_pb2
from protos import image_1_pb2
from .utils import bytes_to_pil_image, image_to_bytes, crop, bytes_to_numpy_array
from .yolo import create_detector


class BrickProcessor(GenericBrickProcessor):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.detection_service = None
        self.configuration = None

    def process(self, request, context):
        print("Processing ")
        run_id = request.images[0].imageID
        if self.configuration is None:
            self.configuration = get_brick().configuration
        if self.detection_service is None:
            self.detection_service = DetectionService(configuration=get_brick().configuration.detection)
        detection_results, detections_dictionary = self.detection_service.process(image_protos=request)
        self.update_meta_store(run_id=run_id, detection_results=detection_results, detections_dictionary=detections_dictionary)
        return detection_results

    def update_meta_store(self, run_id, detection_results, detections_dictionary):
        for detection in detections_dictionary:
            detection["top"] = int(detection["top"])
            detection["left"] = int(detection["left"])
            detection["bottom"] = int(detection["bottom"])
            detection["right"] = int(detection["right"])
            detection["score"] = float(detection["score"])
        try:
            images = []
            for imageDetectionResult in detection_results.imageDetectionResults:
                for detected_object in imageDetectionResult.detectedObjects:
                    numpy_image = bytes_to_numpy_array(detected_object.imageBytes)
                    cv2.imwrite("tmp.jpg", numpy_image)
                    image_bytes = open("tmp.jpg", "rb").read()
                    images.append(image_bytes.decode("utf-8"))
                    # images.append(base64.encodebytes(image_bytes).decode())
            response = requests.post(
                self.configuration.meta_store_api,
                json={
                    "artefact": {
                        "solution_id": 1,
                        "run_id": str(run_id),
                        "images": images,
                        "meta": {"from": "car_detector", "detections": detections_dictionary}
                    }
                }
            )
            if response.status_code == 201:
                return run_id
            else:
                return None
        except Exception as ex:
            print("Error creating artefact ", ex)


class DetectionService:

    def __init__(self, configuration):
        self.detection = create_detector(configuration)

    def process(self, image_protos):
        detection_results = []
        for image_proto in image_protos.images:
            run_id = image_proto.imageID
            pil_image = bytes_to_pil_image(image_proto.imageBytes)
            detections = self.detection.predict(pil_image=pil_image)
            bounding_boxes = []
            detected_objects = []
            print(detections)
            for detection in detections:
                cropped_image = crop(numpy_image=numpy.array(pil_image), coordinates=detection)
                cropped_image_bytes = cropped_image.tobytes()
                width, height, channels = cropped_image.shape
                detected_object = image_1_pb2.Image(imageID=run_id, imageBytes=cropped_image_bytes, imageWidth=width,
                                                    imageHeight=height, numberOfChannels=channels)
                detected_objects.append(detected_object)
                bounding_box = image_detection_3_pb2.BoundingBox(top=detection["top"], left=detection["left"],
                                                                 bottom=detection["bottom"], right=detection["right"],
                                                                 label=detection["label"],
                                                                 confidence=detection["score"])
                bounding_boxes.append(bounding_box)
            detection_result = image_detection_3_pb2.ImageDetectionResult(image=image_proto,
                                                                          boundingBoxes=bounding_boxes,
                                                                          detectedObjects=detected_objects,
                                                                          sentAt=time())
            detection_results.append(detection_result)
        detection_results = image_detection_3_pb2.ImageDetectionResults(imageDetectionResults=detection_results)
        return detection_results, detections
