import colorsys
from time import time

import numpy as np
import onnxruntime as onnxruntime
from PIL import Image, ImageDraw


def create_detector(config):
    data_processor = YOLOv3DataProcessor()
    return YOLOv3Detector(config=config, data_processor=data_processor)


class YOLOv3Detector:

    def __init__(self, config, data_processor):
        self.config = config
        self.data_processor = data_processor
        self.session = onnxruntime.InferenceSession(self.config.model_file_location)

    def predict(self, pil_image):
        preprocessed_image = self.data_processor.preprocess(pil_image)
        image_size = np.array([pil_image.size[1], pil_image.size[0]], dtype=np.float32).reshape(1, 2)

        input_name = self.session.get_inputs()[0].name
        before_session_run = time()
        boxes, scores, classes = self.session.run(None, {input_name: preprocessed_image, "image_shape": image_size})
        print("Session ran in {} seconds".format(time() - before_session_run))
        out_boxes, out_scores, out_classes = [], [], []
        for idx_ in classes:
            out_classes.append(idx_[1])
            out_scores.append(scores[tuple(idx_)])
            idx_1 = (idx_[0], idx_[2])
            out_boxes.append(boxes[idx_1])

        detections = self.data_processor.general_yolo_postprocess(pil_image, out_boxes, out_scores, out_classes)
        return detections


class YOLOv3DataProcessor:

    def __init__(self):
        super().__init__()
        self.input_shape = (416, 416)
        self.anchors = [[10, 13, 16, 30, 33, 23], [30, 61, 62, 45, 59, 119], [116, 90, 156, 198, 373, 326]]
        self.shape = (416, 416)
        self.threshold = 0.7
        self.categories = ['person', 'bicycle', 'vehicle', 'motorbike', 'aeroplane', 'bus', 'train', 'truck', 'boat',
                           'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog',
                           'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella',
                           'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball', 'kite',
                           'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket', 'bottle',
                           'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich',
                           'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'sofa',
                           'pottedplant', 'bed', 'diningtable', 'toilet', 'tvmonitor', 'laptop', 'mouse', 'remote',
                           'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book',
                           'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush']

        self.labels = ['person', 'bicycle', 'car', 'motorbike', 'aeroplane', 'bus', 'train', 'truck', 'boat',
                       'traffic light', 'fire hydrant', 'stop sign', 'parking meter', 'bench', 'bird', 'cat', 'dog',
                       'horse', 'sheep', 'cow', 'elephant', 'bear', 'zebra', 'giraffe', 'backpack', 'umbrella',
                       'handbag', 'tie', 'suitcase', 'frisbee', 'skis', 'snowboard', 'sports ball', 'kite',
                       'baseball bat', 'baseball glove', 'skateboard', 'surfboard', 'tennis racket', 'bottle',
                       'wine glass', 'cup', 'fork', 'knife', 'spoon', 'bowl', 'banana', 'apple', 'sandwich',
                       'orange', 'broccoli', 'carrot', 'hot dog', 'pizza', 'donut', 'cake', 'chair', 'sofa',
                       'pottedplant', 'bed', 'diningtable', 'toilet', 'tvmonitor', 'laptop', 'mouse', 'remote',
                       'keyboard', 'cell phone', 'microwave', 'oven', 'toaster', 'sink', 'refrigerator', 'book',
                       'clock', 'vase', 'scissors', 'teddy bear', 'hair drier', 'toothbrush']
        self.select_classes = [2, 3, 5, 7]

        hsv_tuples = [(x / len(self.categories), 1., 1.)
                      for x in range(len(self.categories))]
        self.colors = list(map(lambda x: colorsys.hsv_to_rgb(*x), hsv_tuples))
        self.colors = list(
            map(lambda x: (int(x[0] * 255), int(x[1] * 255), int(x[2] * 255)),
                self.colors))

    def preprocess(self, img):
        model_image_size = (416, 416)
        boxed_image = self.letter_box_image(img, tuple(reversed(model_image_size)))
        image_data = np.array(boxed_image, dtype='float32')
        image_data /= 255.
        image_data = np.transpose(image_data, [2, 0, 1])
        image_data = np.expand_dims(image_data, 0)
        return image_data

    # This function is from yolo3.utils.letterbox_image
    def letter_box_image(self, image, size):
        '''resize image with unchanged aspect ratio using padding'''
        iw, ih = image.size
        w, h = size
        scale = min(w / iw, h / ih)
        nw = int(iw * scale)
        nh = int(ih * scale)

        image = image.resize((nw, nh), Image.BICUBIC)
        new_image = Image.new('RGB', size, (128, 128, 128))
        new_image.paste(image, ((w - nw) // 2, (h - nh) // 2))
        return new_image

    def postprocess(self, image, boxes, scores, classes):
        thickness = (image.size[0] + image.size[1]) // 300
        detected_vehicle_boxes = []
        for i, c in reversed(list(enumerate(classes))):
            # print(c)
            predicted_class = self.categories[c]
            print(predicted_class)
            box = boxes[i]
            score = scores[i]

            label = '{} {:.2f}'.format(predicted_class, score)
            draw = ImageDraw.Draw(image)

            top, left, bottom, right = box
            top = max(0, np.floor(top + 0.5).astype('int32'))
            left = max(0, np.floor(left + 0.5).astype('int32'))
            bottom = min(image.size[1], np.floor(bottom + 0.5).astype('int32'))
            right = min(image.size[0], np.floor(right + 0.5).astype('int32'))
            # print(label, (left, top), (right, bottom))
            detected_vehicle_boxes.append(dict(top=top, left=left, bottom=bottom, right=right))

            for i in range(thickness):
                draw.rectangle(
                    [left + i, top + i, right - i, bottom - i],
                    outline=self.colors[c])
            del draw
        # print(detected_vehicle_boxes)
        # cv2.imshow("", np.array(image))
        # cv2.waitKey(0)
        return detected_vehicle_boxes

    def general_yolo_postprocess(self, image, boxes, scores, classes):
        thickness = (image.size[0] + image.size[1]) // 300
        detections = []
        for i, c in reversed(list(enumerate(classes))):
            # print(c)
            predicted_class = self.labels[c]
            box = boxes[i]
            score = scores[i]

            label = '{} {:.2f}'.format(predicted_class, score)
            draw = ImageDraw.Draw(image)

            top, left, bottom, right = box
            top = max(0, np.floor(top + 0.5).astype('int32'))
            left = max(0, np.floor(left + 0.5).astype('int32'))
            bottom = min(image.size[1], np.floor(bottom + 0.5).astype('int32'))
            right = min(image.size[0], np.floor(right + 0.5).astype('int32'))

            detections.append(dict(label=predicted_class,
                                   top=top, left=left, bottom=bottom, right=right,
                                   score=score))

        return detections
