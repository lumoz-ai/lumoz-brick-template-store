from io import BytesIO

import cv2
import numpy as np
from PIL import Image


def bytes_to_numpy_array(byte_image, dtype="uint8"):
    try:
        numpy_image = np.frombuffer(byte_image, dtype=dtype)
    except Exception as ex:
        print(ex)
    return numpy_image


def bytes_to_pil_image(byte_image):
    pil_image = Image.open(BytesIO(byte_image))
    return pil_image


def image_to_bytes(image):
    image_file_content = image.tobytes()
    return image_file_content


def crop(numpy_image, coordinates):
    top = coordinates['top']
    left = coordinates['left']
    bottom = coordinates['bottom']
    right = coordinates['right']

    cropped_numpy_image = numpy_image[top:bottom, left:right]

    return cropped_numpy_image
