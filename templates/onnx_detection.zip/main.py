import os
import json

import requests
from bricksdk import BrickFactory
from bricksdk.configurations import Configuration
from bricksdk.utils import Environments

from brick.processor import BrickProcessor

json_configuration = None
if os.environ.get("configuration"):
    json_configuration = json.loads(os.environ.get("configuration"))
configuration = Configuration(environment=Environments.DEBUG_ENV).load(json_configuration)


def download_model(configuration):
    from urllib.parse import urlparse
    if urlparse(configuration.model_file_location).scheme != '':
        try:
            os.mkdir("model")
        except:
            pass
        file_name = configuration.model_file_location.split("/")[-1]
        file_path = os.path.join("model", file_name)
        response = requests.get(configuration.model_file_location)
        with open(file_path, "wb") as f:
            f.write(response.content)
        configuration.model_file_location = file_path


download_model(configuration=configuration.detection)
configuration.meta_store_api = os.environ.get("meta_store_api", "http://0.0.0.0:3000/v1/artefacts")
download_model(configuration.detection)
brick_factory = BrickFactory(
    environment=Environments.DEBUG_ENV, configuration=configuration
).add_brick_processor(brick_processor=BrickProcessor())
brick = brick_factory.create_brick()
brick.initialize_components()
brick.start()
