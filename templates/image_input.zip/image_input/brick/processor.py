from time import time

from bricksdk import get_brick
from bricksdk.brick_processors import InputBrickProcessor
from protos import image_detection_3_pb2


class BrickProcessor:

    def __init__(self):
        self.input_processor = None
        self.configuration = None

    def process(self, request, context):
        print("Solution Runner initiated")
        run_id = int(time())
        if self.input_processor is None:
            self.input_processor = InputBrickProcessor(brick=get_brick())
        if self.configuration is None:
            self.configuration = get_brick().configuration
        request.images[0].imageID = run_id
        start_time = time()
        result = self.input_processor.process(inputs=[request], force_run=False)
        print("The number plate is : {}".format(result.imageOcrResult[0].text))
        print("Graph took {} seconds".format(time() - start_time))
        dummy_result = image_detection_3_pb2.ImageDetectionResults()
        return dummy_result
